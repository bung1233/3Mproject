--회원가입 테이블
create table userinfo(
    userid          varchar2(20) primary key,       --회원 아이디
    username        varchar2(20) not null,          --회원 이름
    password        varchar2(20) not null,          --비밀번호
    email           varchar2(50) not null,          --주소
    age             number       not null,          --나이
    gender          varchar2(10) not null,          --남자,여자
    userimage       clob                            --유저 프로필 사진
);
    

--=================================================================================================================--


--앨범 테이블
create table album(
    abnum           number primary key,             --사진의 고유번호
    userid          varchar2(20) not null,          --앨범 아이디
    abtitle         varchar2(100) not null,         --사진 종류
    image           varchar2(2000) not null,        --앨범 사진
    abdate          date default sysdate            --앨범 등록 날짜
);

--앨범 테이블 번호붙이기 시퀀스
create sequence abnum_seq start with 1 increment by 1;


--=================================================================================================================--


--일기 테이블
create table diary(
    dinum           number primary key,             --게시글 고유번호
    userid          varchar2(20) not null,          --게시글 작성자
    dititle         varchar2(100) not null,         --게시글 이름
    image           clob,                           --사진/이미지
    dicontent       varchar2(4000) not null,          --일기 내용
    dihit           number default 0,         --일기 조회수
    didate          date default sysdate,           --일기 날짜
    dipublic        varchar2(1) not null            --숨기기(0:공개, 1:숨김)
);

--일기 테이블 번호붙이기 시퀀스
create sequence dinum_seq start with 1 increment by 1;


--=================================================================================================================--


--가계부 테이블
create table accountbook(
    acnum           number primary key,             --가계부 고유번호
    userid          varchar2(20) not null,          --가계부 작성자
    actitle         varchar2(100) not null,         --가계부 이름
    image           varchar2(2000),                 --사진/이미지
    acitem          varchar2(4000) not null,        --구매한 물건들
    acprice         varchar2(4000) not null,        --구매한 가격들
    actype          varchar2(4000) not null,        --구매한 물건의 종류들
    acdate          date default sysdate            --가계부 날짜
);

--가계부 테이블 번호붙이기 시퀀스
create sequence acnum_seq start with 1 increment by 1;


--=================================================================================================================--


--메모 테이블
create table memo(
    menum           number primary key,             --메모 고유번호
    userid          varchar2(20) not null,          --메모 작성자
    metitle         varchar2(100) not null,         --메모 이름
    mecontent       varchar2(4000) not null,        --메모 내용
    image           varchar2(2000),                 --사진/이미지
    mevoice         varchar2(500),                  --음성파일
    medate          date default sysdate            --만든 날짜
);

--메모 테이블 번호붙이기 시퀀스
create sequence menum_seq start with 1 increment by 1;


--=================================================================================================================--


--주소록 테이블
create table address(
    adnum           number primary key,             --주소록 고유번호
    userid          varchar2(20) not null,          --주소록 작성자
    adname          varchar2(100) not null,         --주소록 이름
    image           varchar2(2000),                 --사진/이미지
    advoice         varchar2(500),                  --음성파일
    adcontent       varchar2(4000) not null         --주소록 내용(사진만 받을시 삭제)
);

--주소록 테이블 번호붙이기 시퀀스
create sequence adnum_seq start with 1 increment by 1;


--=================================================================================================================--


--Q&A게시판 테이블
create table qaboard(
    qanum           number primary key,             --질문게시글 고유번호
    userid          varchar2(20) not null,          --게시글 작성자
    qatitle         varchar2(100) not null,          --게시글 이름
    qacontent       varchar2(4000) not null,        --게시글 내용
    qadate          date default sysdate            --게시판 날짜
);

--Q&A게시판 테이블 번호붙이기 시퀀스
create sequence qaboard_seq start with 1 increment by 1;
