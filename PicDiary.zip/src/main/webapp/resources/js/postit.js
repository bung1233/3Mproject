// wait until the dom document is loaded
jQuery(document).ready(function(){

	// listen for a .click() event on the canvas element
	$('#postitload').click(function(e){ makeNote(e); });
});

function makeNote (e) {
		if (e.eventPhase === 2) {
			var padd = '<div id="newpostit" name="newpostit" max-width="10px !important" width="10px !important" style="border: 1px solid black;';
			padd += 'background: #ffeb81; font-size:13.3px; line-height:1;" align="right">';
			
			//닫기 버튼
			padd += '<abbr title="닫기"><a id="close" onclick="deleteNote();"';
			padd += 'onMouseOver="changecolor(id);" onMouseOut="changecolor2(id)" style="font-size:13.3px;">';
			padd += '<img id="close" src="./resources/img/memo/close.png" width="15px" height="15px"></a></abbr>';
			//제목 폼
			padd += '<br><input type="text" id="metitle" name="metitle" autocomplete="off"';
			padd += 'display="block" style="background-color:transparent; font-size:13.3px;';
			padd += 'border:0 solid black; margin:0; padding:0; height: 18px; " size="31" placeholder="Insert Title"><br>';
			//내용 폼
			padd += '<textarea id="mecontent" rows="8" cols="30%"';
			padd += 'style="background-color: #fff2ab; resize: none; margin:0; padding:0;';
			padd += 'font-size:13.3px; min-height:200px" placeholder="Insert Content">';
			padd += '</textarea><br><b max-width="10px" id="recordingsList" display="block"></b>';
			//사진 버튼
			padd += '<abbr title="이미지 등록"><a style="font-size:40" id="Ibutton" onclick="fileup();"';
			padd += 'onMouseOver="changecolor(id);" onMouseOut="changecolor2(id)" float="right">';
			padd += '<img id="loadimg" src="./resources/img/memo/image.png" width="30px" height="30px"></a></abbr>';
			
			//음성 버튼
			padd += '<abbr title="음성으로 등록"><a style="font-size:40" id="Vbutton"';
			padd += 'onMouseOver="changecolor(id);" onMouseOut="changecolor2(id)"';
			padd += 'onclick="starts();" float="right" onclick="starts()">';
			padd += '<img id="loadvoice" src="./resources/img/memo/voice.png" width="30px" height="30px"></a></abbr>';
			
			//음성멈춤 버튼
			padd += '<abbr title="녹음 종료"><a style="font-size:40; display:none;" id="Sbutton"';
			padd += 'onMouseOver="changecolor(id);" onMouseOut="changecolor2(id)"';
			padd += 'onclick="stops();" float="right">';
			padd += '<img src="./resources/img/memo/voiceStop.png" width="30px" height="30px"></a></abbr>'
			
			//저장 버튼
			padd += '<abbr title="저장"><a style="font-size:40" id="write"';
			padd += ' onclick="savedata();"';	//저장 버튼 원클릭 이벤트
			padd += 'onMouseOver="changecolor(id);" onMouseOut="changecolor2(id)" float="right">';
			padd += '<img id="submit" src="./resources/img/memo/submit.png" width="30px" height="30px"></a></abbr>';
			padd += '<input type="hidden" id="image">';
			padd += '<input type="hidden" id="mevoice">';
			padd += '</div>';
			var postit = $(padd).draggable();	//.resizable() 안됨....
			$('#postit').prepend(postit);
			document.getElementById('Pbutton').style.display="none";
		}
}

//메모 닫기
function deleteNote() {
	if(save!='1'){
		if(confirm('You have not saved')){
			document.getElementById('Pbutton').style.display="block";
			$('#newpostit').remove();
		}
	}
	else{
		document.getElementById('Pbutton').style.display="block";
		$('#newpostit').remove();
		save = 0*1;
	}
}

var save = 0*1;
//메모 저장하기
function savedata(){
	var metitle = document.getElementById('metitle').value;
	var mecontent = document.getElementById('mecontent').value;
	var mevoice = document.getElementById('mevoice').value;
	
		if(metitle==''||metitle=='제목을 입력하세요'){
			alert('Please enter a title');
		}
		else{
			if(mecontent==''||mecontent=='텍스트를 입력하세요'){
				alert('Please enter your content');
			}
			else{
				$.ajax({
					url: 'mewrite'
					, type: 'POST'
					, data: {metitle : metitle, mecontent : mecontent, mevoice : mevoice}
					, dataType: "text"
					, success: function(){
						document.getElementById('Pbutton').style.display="block";
						$('#newpostit').remove();
						alert('Save Success');
						save = 1;
					}
					, error: function(e){
						alert(JSON.stringify(e));
					}
				});
			}
		}
}

//파일업로드
function fileup(){ $('#photoup').click(); }

function starts(){
	$('#recordButton').click();
	document.getElementById('Vbutton').style.display = "none";
	document.getElementById('Sbutton').style.display = "inline-block";
}

function stops(){
	$('#stopButton').click();
	document.getElementById('Vbutton').style.display = "inline-block";
	document.getElementById('Sbutton').style.display = "none";
}

//메모 메뉴에 마우스 올렸을 때 색 변하기
function changecolor(id){
	if(id=='maxmin'){$('#maxmin').css('background-color','#eedb78');}
	if(id=='close'){$('#close').css('background-color','#eedb78');}
	if(id=='Lbutton'){$('#Lbutton').css('background-color','#eedb78');}
	if(id=='Ibutton'){$('#Ibutton').css('background-color','#eedb78');}
	if(id=='Vbutton'){$('#Vbutton').css('background-color','#eedb78');}
	if(id=='Sbutton'){$('#Sbutton').css('background-color','#eedb78');}
	if(id=='write'){$('#write').css('background-color','#eedb78');}
}

//메모 메뉴에 마우스 땠을 때 색 변하기
function changecolor2(id){
	if(id=="maxmin"){$('#maxmin').css('background-color','#ffeb81');}
	if(id=="close"){$('#close').css('background-color','#ffeb81');}
	if(id=='Lbutton'){$('#Lbutton').css('background-color','#ffeb81');}
	if(id=='Ibutton'){$('#Ibutton').css('background-color','#ffeb81');}
	if(id=='Vbutton'){$('#Vbutton').css('background-color','#ffeb81');}
	if(id=='Sbutton'){$('#Sbutton').css('background-color','#ffeb81');}
	if(id=='write'){$('#write').css('background-color','#ffeb81');}
}

