
$(document).ready(function(){
	//radio의 변경이 일어났을 때 발생하는 이벤트
	$("input[name='inputtype']:radio").change(function(){
		//inputtype값을 받음
		var inputtype = this.value;
		//if문으로 비교해서 사진입력부분은 숨기고 직접입력부분은 드러냄
		if(inputtype == "write"){
			$("#photo").hide();
			$("#write").show();
		}
		//if문으로 비교해서 직접입력부분은 숨기고 사진입력부분은 드러냄
		else if(inputtype == "photo"){
			$("#photo").show();
			$("#write").hide();
		}
	});
	//직접입력부분의 메뉴추가 이벤트
	$('#addMenu').on('click',addmenu);
});

$(document).on("click","button[name=delStaff]",function(){
	//버튼의 부모는 td, td의 부모는 tr
	var trHtml = $(this).parent().parent();
	trHtml.remove(); //tr 테그 삭제
	var size = $("input[name='item']").length;
	var sum = 1*0;
	for(var z = 0*1; z < size; z++){
		sum += Number(vv[z]);
	}
	document.getElementById('insertmoneys').innerHTML = sum;
	insertitem();
});

var x = 1;
function addmenu(){
	var add = '';
	x = x + 1;
	add+= '<tr name="inputlist"><td>';
	add+= '<input type="text" id="acitem'+ x +'" name="item" onkeyup="insertitem()"></td>';
	add+= '<td><input type="text" id="acprice'+ x;
	add+= '" onkeyup="insertprice(this.id, this.value)" autocomplete="off"></td>';
	add+= '<td><select id="actype'+ x +'"><option value="cloth">의류</option>';
	add+= '<option value="food">식류</option>';
	add+= '<option value="culture">문화</option>';
	add+= '<option value="vaction">여가</option>';
	add+= '<option value="etc" selected>기타</option></select></td>';
	add+= '<td><button class="btn btn-default" name="delStaff">삭제</button></td>';
	add+= '</tr>';
	var trHtml = $("tr[name=inputlist]:last");
	trHtml.after(add);
}

function rewrite(){
	var title = document.getElementById('actitle').value;
	if(title.length<1){
		alert('제목을 입력해주세요.');
		return false;
		alert('false작동안함');
	}
	else{
		alert('다 입력됨');
		var selectitem = '';	//총 상품 목록
		var selectprice = '';	//총 가격 목록
		var selecttype = '';	//총 분류 목록
		var selected = $("input[name='item']").length;	//총 아이템개수
		for(var selects = 1; selects <= selected; selects++){
				selectitem += document.getElementById('acitem'+selects).value;
				selectprice += document.getElementById('acprice'+selects).value;
				selecttype += document.getElementById('actype'+selects).value;
			if(selects!=selected){
				selectitem += ',';
				selectprice += ',';
				selecttype += ',';
			}
		}
		var selectimage = img64string;
		document.getElementById('acitem').value = selectitem;
		document.getElementById('acprice').value = selectprice;
		document.getElementById('actype').value = selecttype;
		document.getElementById('image').value = selectimage;
		return true;
	}
	return false;
}

function ptrewrite(){
	var title = document.getElementById('ptactitle').value;
	if(title.length<1){
		alert('제목을 입력해주세요.');
		return false;
	}
	else{
		var selectitem = '';	//총 상품 목록
		var selectprice = '';	//총 가격 목록
		var selecttype = '';	//총 분류 목록
		var selected = $("input[name='ptitem']").length;	//총 아이템개수
		for(var selects = 1; selects <= selected; selects++){
				selectitem += document.getElementById('ptacitem'+selects).value;
				selectprice += document.getElementById('ptacprice'+selects).value;
				selecttype += document.getElementById('ptactype'+selects).value;
			if(selects!=selected){
				selectitem += ',';
				selectprice += ',';
				selecttype += ',';
			}
		}
		alert(selectitem);
		var selectimage = img64string;
		document.getElementById('acitem').value = selectitem;
		document.getElementById('acprice').value = selectprice;
		document.getElementById('actype').value = selecttype;
		document.getElementById('image').value = selectimage;
		document.getElementById('labeling').value = labelstring;
	return true;
	}
}

function insertprice(id, value){
	var reid = id.replace("acprice","");
	reid--;
	var size = $("input[name='item']").length;
	var sum = 1*0;
	vv[reid] = value*1;
	for(var z = 0*1; z < size; z++){
		sum += Number(vv[z]);
	}
	document.getElementById('insertmoneys').innerHTML = sum;
}

function insertitem(){
	var size = $("input[name='item']").length;
	
	for(var z = 0; z < size; z++){
		if(document.getElementById('acitem'+z)!=""&&document.getElementById('acitem'+z)!=" "){}
		else{
			size--;
		}
	}
	document.getElementById('insertitems').innerHTML = size;
}