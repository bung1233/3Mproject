//아이디 충복 체크
function idcheck() {
	var id = document.getElementById('custid');
	var input = prompt('아이디 중복 체크', '아이디를 입력해주세요');
	
	if(input == null) {
		input = "아이디의 입력이 필요합니다";
		return false;
	}
	location.href='idcheck?custid='+input;
}

function formcheck(){	
    var id = document.getElementById('custid');
    var pw1 = document.getElementById('password');
    var pw2 = document.getElementById('password2');
    var name = document.getElementById('name');
 
    if(id.value.length < 3){
       alert('아이디를 3자이상입력해주세요');

       return false;
    }
    if(pw1.value.length < 3){
       alert('비밀번호를3자이상입력해주세요');
    
       return false;
    }
     if(pw1.value != pw2.value ){
          alert("비밀번호가 같지 않습니다.");
          return false;
      }
    if(name.value.length < 1){
       alert('이름을 적어주세요');
    
       return false;
    }
    return true;
 }
//이메일 처리 js
function SetEmailtail(emailvalue){
	var email = document.all("email")
	var emailtail = document.all("email2")

	if (emailvalue == "notSelected") {
		return;
	}
	else if(emailvalue == "etc") {
		emailtail.readOnly = false;
		emailtail.value = "";
		emailtail.focus();
	}
	else {
		emailtail.readOnly = true;
		emailtail.value = emailvalue;
	}
}