package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import Project.threeM.PicDiary.VO.AccountBookVO;

public interface AccountBookMapper {

	public int acwrite(AccountBookVO acvo);

	public ArrayList<AccountBookVO> acread(String userid);

	public ArrayList<Object> acitems(String userid);

	public ArrayList<Object> acprices(String userid);

	public String loaditem(AccountBookVO acvo);

	public String loadprice(AccountBookVO acvo);

	public ArrayList<AccountBookVO> acrewriteread(AccountBookVO acvo);

	public int acrewriting(AccountBookVO acvo);

	public int acdelete(AccountBookVO acvo);

	public ArrayList<AccountBookVO> acread1(AccountBookVO acvo);

	public int getTotal(String userid);

	public ArrayList<AccountBookVO> aclist(RowBounds rb, String userid);

	public ArrayList<AccountBookVO> aclist2(RowBounds rb, AccountBookVO acvo);
	
	
}
