package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;
import org.apache.ibatis.session.RowBounds;

import Project.threeM.PicDiary.VO.DiaryVO;




public interface DiaryMapper {

	public int insert(DiaryVO divo);

	public int getTotal(String userid);

	public ArrayList<DiaryVO> dilist(RowBounds rb, String userid);

	public DiaryVO diread1(int dinum);

	public void diaryHits(int dinum);

	public void update(DiaryVO divo);

	public void delete(DiaryVO divo);

	public ArrayList<DiaryVO> all();

	public int gettotal(String searchText);

	public ArrayList<DiaryVO> searchlist(RowBounds rb, String searchText);

	public ArrayList<DiaryVO> popular();

	public String userimg(String userid);

	public int numab(String loginid);

	public int numdi(String loginid);

	public int numac(String loginid);

	public int numad(String loginid);

	public int numme(String loginid);

	public ArrayList<DiaryVO> dilist2(RowBounds rb, DiaryVO divo);
	

}
