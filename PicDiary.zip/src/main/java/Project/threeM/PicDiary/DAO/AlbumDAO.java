package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.AlbumVO;



@Repository	
public class AlbumDAO {

	
	@Autowired	//root-context의 <bean>으로 클래스 생성
	SqlSession sqlSession;
	
//	사진 등록
		public int insert(AlbumVO abvo) {
			AlbumMapper mapper= sqlSession.getMapper(AlbumMapper.class);
			int result = 0;
			try {
				result = mapper.insert(abvo);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
			return result;
		}
//전체글개수
		public int getTotal(String userid) {
			AlbumMapper mapper = sqlSession.getMapper(AlbumMapper.class);
			int cnt = mapper.getTotal(userid);
			return cnt;
		}
//앨범리스트 10개씩 출력		
		public ArrayList<AlbumVO> ablist(int startRecord, int countPerPage, String userid) {
			AlbumMapper mapper= sqlSession.getMapper(AlbumMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			
			try {
				ArrayList<AlbumVO> list = mapper.ablist(rb, userid);
				return list;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		public ArrayList<AlbumVO> abreceipt(int startRecord, int countPerPage, String searchText) {
			AlbumMapper mapper= sqlSession.getMapper(AlbumMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			
			try {
				ArrayList<AlbumVO> list = mapper.abreceipt(rb, searchText);
				return list;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		public ArrayList<AlbumVO> abdocument(int startRecord, int countPerPage, String searchText) {
			AlbumMapper mapper= sqlSession.getMapper(AlbumMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			
			try {
				ArrayList<AlbumVO> list = mapper.abdocument(rb, searchText);
				return list;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		public ArrayList<AlbumVO> ablist2(int startRecord, int countPerPage, AlbumVO abvo) {
			ArrayList<AlbumVO>list = new ArrayList<AlbumVO>();
			AlbumMapper mapper= sqlSession.getMapper(AlbumMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			try{
				list = mapper.ablist2(rb,abvo);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return list;
		}
	
}
