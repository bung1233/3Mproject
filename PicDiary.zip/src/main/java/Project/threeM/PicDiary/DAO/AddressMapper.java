package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;
import org.apache.ibatis.session.RowBounds;
import Project.threeM.PicDiary.VO.AddressVO;

public interface AddressMapper {
	
	public int insert(AddressVO advo);

	public int getTotal(String userid);

	public ArrayList<AddressVO> adlist(RowBounds rb, String userid);

	public int insertdi(AddressVO advo);

	public void update(AddressVO advo);

	public void deleting(AddressVO advo);

	public ArrayList<AddressVO> adlist2(RowBounds rb, AddressVO advo);

}
