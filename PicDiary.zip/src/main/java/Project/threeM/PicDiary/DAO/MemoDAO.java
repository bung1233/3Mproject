package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.MemoVO;

@Repository
public class MemoDAO {

	@Autowired
	SqlSession sqlSession;

	//메모 쓰기
	public int mewrite(MemoVO mevo) {
		int cnt = 0;
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		try{
			cnt = mapper.mewrite(mevo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return cnt;
	}

	//메모 리스트 출력
	public ArrayList<MemoVO> melist(int start, int count, String userid) {
		ArrayList<MemoVO>list = new ArrayList<MemoVO>();
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		RowBounds rb = new RowBounds(start, count);		//행번호 , 개수
		try{
			list = mapper.melist(rb, userid);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

	//메모 수정
	public void update(MemoVO mevo) {
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		mapper.update(mevo);
	}

	//메모 삭제
	public void deleting(MemoVO mevo) {
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		mapper.deleting(mevo);
	}

	//현재 전체 글 개수
	public int getTotal(String userid) {
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		int cnt = mapper.getTotal(userid);
		return cnt;
	}
	
	//검색
	public ArrayList<MemoVO> melist2(int start, int count, MemoVO mevo) {
		ArrayList<MemoVO>list = new ArrayList<MemoVO>();
		MemoMapper mapper = sqlSession.getMapper(MemoMapper.class);
		RowBounds rb = new RowBounds(start, count);		//행번호 , 개수
		try{
			list = mapper.melist2(rb, mevo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

}
