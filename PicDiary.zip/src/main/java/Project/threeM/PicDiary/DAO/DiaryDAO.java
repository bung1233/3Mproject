package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.DiaryVO;

@Repository	
public class DiaryDAO {
	
	@Autowired	//root-context의 <bean>으로 클래스 생성
	SqlSession sqlSession;
	
//일기 등록
		public int insert(DiaryVO divo) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			int result = 0;
			try {
				result = mapper.insert(divo);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}

		public int getTotal(String userid) {
			DiaryMapper mapper = sqlSession.getMapper(DiaryMapper.class);
			int cnt = mapper.getTotal(userid);
			return cnt;
		}

		public ArrayList<DiaryVO> dilist(int startRecord, int countPerPage, String userid) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			
			try {
				ArrayList<DiaryVO> list = mapper.dilist(rb, userid);
				return list;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
// 다이어리 보드원
		public DiaryVO diread1(int dinum) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			
			try {
				DiaryVO divo = mapper.diread1(dinum);
				return divo;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		}
//	조회수 1 증가
		public void diaryHits(int dinum) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				mapper.diaryHits(dinum);
	
			}
			
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void update(DiaryVO divo) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				mapper.update(divo);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void delete(DiaryVO divo) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				mapper.delete(divo);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public ArrayList<DiaryVO> all() {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			ArrayList<DiaryVO>list = new ArrayList<DiaryVO>();
			try {
				list = mapper.all();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return list;
		}

		public int gettotal(String searchText) {
			int total = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				total = mapper.gettotal(searchText);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return total;
		}

		public ArrayList<DiaryVO> searchlist(int startRecord, int countPerPage, String searchText) {
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			ArrayList<DiaryVO> list = new ArrayList<DiaryVO>();
			try {
				list = mapper.searchlist(rb, searchText);
			}
			
			catch (Exception e) {
				e.printStackTrace();
			}
			return list;
		}

		public ArrayList<DiaryVO> popular() {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			ArrayList<DiaryVO>list = new ArrayList<DiaryVO>();
			try {
				list = mapper.popular();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return list;
		}

		public String userimg(String userid) {
			String userimage = null;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				userimage = mapper.userimg(userid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return userimage;
		}

		public int numab(String loginid) {
			int num = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				num = mapper.numab(loginid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return num;
		}

		public int numdi(String loginid) {
			int num = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				num = mapper.numdi(loginid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return num;
		}

		public int numac(String loginid) {
			int num = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				num = mapper.numac(loginid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return num;
		}

		public int numad(String loginid) {
			int num = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				num = mapper.numad(loginid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return num;
		}

		public int numme(String loginid) {
			int num = 0;
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			try {
				num = mapper.numme(loginid);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return num;
		}

		public ArrayList<DiaryVO> dilist2(int startRecord, int countPerPage, DiaryVO divo) {
			DiaryMapper mapper= sqlSession.getMapper(DiaryMapper.class);
			RowBounds rb = new RowBounds(startRecord, countPerPage);		//행번호 , 개수
			
			try {
				ArrayList<DiaryVO> list = mapper.dilist2(rb, divo);
				return list;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

}
