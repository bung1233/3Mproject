package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.AccountBookVO;
import Project.threeM.PicDiary.VO.MemoVO;

@Repository
public class AccountBookDAO {
	
	@Autowired
	SqlSession sqlSession;

	public int acwrite(AccountBookVO acvo) {
		int cnt = 0;
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			cnt = mapper.acwrite(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return cnt;
	}

	public ArrayList<AccountBookVO> acread(String userid) {
		ArrayList<AccountBookVO>acbook = new ArrayList();
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			acbook = mapper.acread(userid);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return acbook;
	}

	public String loaditem(AccountBookVO acvo) {
		String items = "";
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			items = mapper.loaditem(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return items;
	}

	public String loadprice(AccountBookVO acvo) {
		String prices = "";
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			prices = mapper.loadprice(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return prices;
	}

	public ArrayList<AccountBookVO> acrewriteread(AccountBookVO acvo) {
		ArrayList<AccountBookVO>acbook = new ArrayList();
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			acbook = mapper.acrewriteread(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return acbook;
	}

	public int acrewriting(AccountBookVO acvo) {
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		int cnt = 0;
		try{
			cnt = mapper.acrewriting(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return cnt;
	}

	public int acdelete(AccountBookVO acvo) {
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		int cnt = 0;
		try{
			cnt = mapper.acdelete(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return cnt;
	}

	public ArrayList<AccountBookVO> acread1(AccountBookVO acvo) {
		ArrayList<AccountBookVO>acbook = new ArrayList();
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		try{
			acbook = mapper.acread1(acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return acbook;
	}

	public int getTotal(String userid) {
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		int cnt = mapper.getTotal(userid);
		return cnt;
	}

	public ArrayList<AccountBookVO> aclist(int start, int count, String userid) {
		ArrayList<AccountBookVO>list = new ArrayList<AccountBookVO>();
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		RowBounds rb = new RowBounds(start, count);		//행번호 , 개수
		try{
			list = mapper.aclist(rb, userid);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<AccountBookVO> aclist2(int start, int count, AccountBookVO acvo) {
		ArrayList<AccountBookVO>list = new ArrayList<AccountBookVO>();
		AccountBookMapper mapper = sqlSession.getMapper(AccountBookMapper.class);
		RowBounds rb = new RowBounds(start, count);		//행번호 , 개수
		try{
			list = mapper.aclist2(rb, acvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
}
