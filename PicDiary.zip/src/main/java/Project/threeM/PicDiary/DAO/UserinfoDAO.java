package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.UserinfoVO;


@Repository	
public class UserinfoDAO {

	
	@Autowired	//root-context의 <bean>으로 클래스 생성
	SqlSession sqlSession;

	//삽입 dao
	public int insert(UserinfoVO usvo) {
		UserinfoMapper mapper = sqlSession.getMapper(UserinfoMapper.class);

		int result = 0;
			try{
			result = mapper.insert(usvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	//회원 ID 중복 검색 
	public UserinfoVO getCustomer(String searchid) {
		UserinfoMapper mapper= sqlSession.getMapper(UserinfoMapper.class);
			
		UserinfoVO vo = null;
		try {
			vo = mapper.searchID(searchid);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}

	//로그인 dao
	public UserinfoVO login(UserinfoVO usvo) {
		UserinfoMapper mapper = sqlSession.getMapper(UserinfoMapper.class);
		UserinfoVO result = null;

		try {
			result = mapper.login(usvo);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	//수정 dao
	public int update(UserinfoVO usvo) {
		UserinfoMapper mapper = sqlSession.getMapper(UserinfoMapper.class);

		int result = 0;

		try{
			result = mapper.update(usvo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return result;	
	}

	//회원 정보 출력  dao
	public UserinfoVO logininfo(String userid) {
		UserinfoMapper mapper = sqlSession.getMapper(UserinfoMapper.class);

		UserinfoVO result = null;

		try {
			result = mapper.logininfo(userid);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	//삭제 dao
	public int delete(HashMap<String, String> map) {
		UserinfoMapper mapper = sqlSession.getMapper(UserinfoMapper.class);

		int result = 0;

		try {
			result = mapper.delete(map);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
}
