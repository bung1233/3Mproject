package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import Project.threeM.PicDiary.VO.AlbumVO;


public interface AlbumMapper {

	public int insert(AlbumVO abvo);

	public int getTotal(String userid);
//앨범리스트(전체/가계부/문서/명함)
	public ArrayList<AlbumVO> ablist(RowBounds rb, String userid);

	public ArrayList<AlbumVO> abreceipt(RowBounds rb, String searchText);

	public ArrayList<AlbumVO> abdocument(RowBounds rb, String searchText);

	public ArrayList<AlbumVO> ablist2(RowBounds rb, AlbumVO abvo);



}
