package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.RowBounds;

import Project.threeM.PicDiary.VO.DiaryVO;
import Project.threeM.PicDiary.VO.UserinfoVO;



public interface UserinfoMapper {

	public int insert(UserinfoVO usvo);

	public UserinfoVO searchID(String searchid);

	public UserinfoVO login(UserinfoVO usvo);

	public int update(UserinfoVO usvo);

	public int delete(HashMap<String, String> map);

	public UserinfoVO logininfo(String userid);








}
