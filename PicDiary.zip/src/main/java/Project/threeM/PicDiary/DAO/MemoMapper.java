package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import Project.threeM.PicDiary.VO.MemoVO;

public interface MemoMapper {

	public int mewrite(MemoVO mevo);

	public ArrayList<MemoVO> melist(RowBounds rb, String userid);

	public void update(MemoVO mevo);

	public void deleting(MemoVO mevo);

	public int getTotal(String userid);

	public ArrayList<MemoVO> melist2(RowBounds rb, MemoVO mevo);

}
