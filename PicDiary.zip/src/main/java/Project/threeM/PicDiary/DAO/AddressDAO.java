package Project.threeM.PicDiary.DAO;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Project.threeM.PicDiary.VO.AccountBookVO;
import Project.threeM.PicDiary.VO.AddressVO;
import Project.threeM.PicDiary.VO.MemoVO;

@Repository
public class AddressDAO {

	@Autowired	//root-context�쓽 <bean>�쑝濡� �겢�옒�뒪 �깮�꽦
	SqlSession sqlSession;

	//二쇱냼濡� �벑濡�
	public int insert(AddressVO advo) {
		AddressMapper mapper= sqlSession.getMapper(AddressMapper.class);
		int result = 0;
		try {
			result = mapper.insert(advo);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//�쟾泥닿�媛쒖닔
	public int getTotal(String userid) {
		AddressMapper mapper = sqlSession.getMapper(AddressMapper.class);
		int cnt = mapper.getTotal(userid);
		return cnt;
	}
	//二쇱냼濡� 由ъ뒪�듃 10媛쒖뵫 異쒕젰		
	public ArrayList<AddressVO> adlist(int startRecord, int countPerPage, String userid) {
		AddressMapper mapper= sqlSession.getMapper(AddressMapper.class);
		RowBounds rb = new RowBounds(startRecord, countPerPage);		//�뻾踰덊샇 , 媛쒖닔

		try {
			ArrayList<AddressVO> list = mapper.adlist(rb, userid);
			return list;
		}

		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	//吏곸젒 �벑濡�
	public int insertdi(AddressVO advo) {
		AddressMapper mapper= sqlSession.getMapper(AddressMapper.class);
		int result = 0;
		try {
			result = mapper.insertdi(advo);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
	public void update(AddressVO advo) {
		AddressMapper mapper= sqlSession.getMapper(AddressMapper.class);
		mapper.update(advo);
	}
	public void deleting(AddressVO advo) {
		AddressMapper mapper= sqlSession.getMapper(AddressMapper.class);
		mapper.deleting(advo);
	}
	public ArrayList<AddressVO> adlist2(int start, int count, AddressVO advo) {
		ArrayList<AddressVO>list = new ArrayList<AddressVO>();
		AddressMapper mapper = sqlSession.getMapper(AddressMapper.class);
		RowBounds rb = new RowBounds(start, count);		//�뻾踰덊샇 , 媛쒖닔
		try{
			list = mapper.adlist2(rb, advo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
}
