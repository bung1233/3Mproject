package Project.threeM.PicDiary.Controller;

import java.io.File;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Project.threeM.PicDiary.DAO.DiaryDAO;
import Project.threeM.PicDiary.UTIL.APIExamSTT;
import Project.threeM.PicDiary.UTIL.PageNavigator;
import Project.threeM.PicDiary.VO.DiaryVO;
import Project.threeM.PicDiary.VO.UserinfoVO;
import Project.threeM.PicDiary.VO.AlbumVO;
import Project.threeM.PicDiary.DAO.AlbumDAO;


@Controller
public class DiaryController {
   
   @Autowired
   DiaryDAO dao;
   @Autowired
   AlbumDAO adao;
   
   private static final int countPerPage = 9;      //페이지당 글 수
   private static final int pagePerGroup = 5;      //페이지 이동 링크 그룹 당 페이지 수
   
   private static final Logger logger = LoggerFactory.getLogger(DiaryController.class);   
   
   // 수정폼 GET
   @RequestMapping(value = "/direwriteForm", method = RequestMethod.GET)
   public String direwriteForm(int dinum, HttpSession session, Model model) {
      logger.info("direwriteForm");

      //dinum으로 일기 검색
      DiaryVO divo = dao.diread1(dinum);         
      logger.debug("{}", divo);

      //divo를 모델에 저장하고 수정폼 JSP로 포워딩
      model.addAttribute("divo", divo);
      return "diary/direwriteForm";
   }
   // 수정폼 POST
   @RequestMapping(value = "/direwrite", method = RequestMethod.POST)
   public String direwrite(DiaryVO divo,HttpSession session) {
      logger.info("direwriteForm");
      String userid = (String)session.getAttribute("loginid");
      divo.setUserid(userid);
      logger.debug("divo:{}",divo);
      dao.update(divo);
      logger.debug("title:{}",divo.getDititle());
      return "redirect:dilistForm";
   }
   
   
   //삭제
      @RequestMapping(value = "/didelete", method = RequestMethod.POST)
      public String didelete(DiaryVO divo,HttpSession session) {
         logger.info("didelete"
               );
         String userid = (String)session.getAttribute("loginid");
         divo.setUserid(userid);
         logger.debug("divo:{}",divo);
         dao.delete(divo);
         return "redirect:dilistForm";
      }
   
   //직접입력
   @RequestMapping(value = "/diwriteForm", method = RequestMethod.GET)
   public String diwriteForm() {
      logger.info("diwriteForm");
      
      return "diary/diwriteForm";
   }

   //diwrite 폼전송   
   @RequestMapping(value = "/diwrite", method = RequestMethod.POST)
   public String writeForm(AlbumVO abvo
         , DiaryVO divo
         , HttpSession session) {
      logger.debug("vo:{}",divo);
      String userid = (String)session.getAttribute("loginid");
      abvo.setUserid(userid);
      divo.setUserid(userid);
      logger.debug("abvo:{}",abvo);
      logger.debug("vo:{}",divo);
      
      if(abvo.getImage()!=null){
      adao.insert(abvo);
      }
      
      dao.insert(divo);

      return "redirect:/dilistForm";
   }

   //다이어리 리스트   
   @RequestMapping(value = "/dilistForm", method = RequestMethod.GET)
   public String dilistForm(
         @RequestParam(value="page", defaultValue="1") int page
         ,@RequestParam(value="searchText", defaultValue="") String searchText
         ,@RequestParam(value="image", defaultValue="") String image
         ,Model model, HttpSession session, DiaryVO divo){
	  String userid = (String) session.getAttribute("loginid");
	  ArrayList<DiaryVO> list = new ArrayList<DiaryVO>();
      //         현재 전체 글 개수      
      int total = dao.getTotal(userid);
      //         한 페이지에 10개씩 리스트 출력   
      PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
      model.addAttribute("navi", navi);
      model.addAttribute("searchText", searchText);
      model.addAttribute("error",null);
      //         일기리스트( 페이지 , 검색 )
      list = dao.dilist(navi.getStartRecord(), navi.getCountPerPage(), userid);
      if(searchText.length()>0){
			logger.info("검색단어:{}",searchText);
			divo.setDititle(searchText);
			divo.setUserid(userid);
			list = dao.dilist2(navi.getStartRecord(), navi.getCountPerPage(), divo);
			if(list.size()==0){
				model.addAttribute("error","검색한 결과가 없습니다.");
			}
		}
      model.addAttribute("list", list);
      return "diary/dilistForm";   
   }


   //다이어리 보드원
   @RequestMapping(value = "/diOneread", method = RequestMethod.GET)
   public String diOneread(
         @RequestParam(value="dinum", defaultValue="0") int dinum
         , Model model) {
      logger.info("diOneread dinum :" + dinum);
      //dinum으로 검색하여 divo에 저장
      DiaryVO divo = dao.diread1(dinum);
      //logger.debug("divo:{}",divo);
      model.addAttribute("divo", divo);
      //   조회수 1 증가
      dao.diaryHits(dinum);

      return "diary/diOneread";
   }
	
   //보이스 내용을 텍스트로
	@ResponseBody
	@RequestMapping(value = "SpeechTotext", method = RequestMethod.POST, produces="application/json; charset=UTF-8")
	public String SpeechTotext(Model model, HttpSession session, String fileName, String base64text) {
	logger.debug("파일이름 :" + fileName);
		
	APIExamSTT stt = new APIExamSTT();
	String stt1 = stt.STT(fileName);
	logger.debug(stt1);
	model.addAttribute("base64", base64text);
	
	return stt1;
  }
	
}