package Project.threeM.PicDiary.Controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Project.threeM.PicDiary.DAO.AccountBookDAO;
import Project.threeM.PicDiary.DAO.AlbumDAO;
import Project.threeM.PicDiary.UTIL.PageNavigator;
import Project.threeM.PicDiary.VO.AccountBookVO;
import Project.threeM.PicDiary.VO.AlbumVO;

@Controller
public class AccountBookController {

	private static final int countPerPage = 9;		//페이지당 글 수
	private static final int pagePerGroup = 5;		//페이지 이동 링크 그룹 당 페이지 수
   
   private static final Logger logger = LoggerFactory.getLogger(AccountBookController.class);
   
   @Autowired
   AccountBookDAO dao;
   @Autowired
   AlbumDAO adao;
   
   @RequestMapping(value = "/acwriteForm", method = RequestMethod.GET)
   public String acwrite() {
      
      return "accountbook/acwriteForm";
   }
   
   @RequestMapping(value = "/acrewriteForm", method = RequestMethod.GET)
   public String acrewriteform() {
      
      return "accountbook/acrewriteForm";
   }

   @RequestMapping(value = "/acwrite", method = RequestMethod.POST)
   public String acwrite(AccountBookVO acvo, String image, HttpSession session) {
      String userid = (String)session.getAttribute("loginid");
      logger.info("image:{}",image);
      AlbumVO abvo = new AlbumVO();
      abvo.setUserid(userid);
      abvo.setImage(image);
      abvo.setAbtitle(acvo.getActitle());
      logger.debug("abvo:{}",abvo);
      if(acvo.getActitle()==""||acvo.getActitle()==null){
         return "accountbook/acwriteForm";
      }
     String img = abvo.getImage();
     int length = abvo.getImage().length();
     String check = img.replace(",","");
     check = check.replace("base64", "base64,");
     abvo.setImage(check);
     acvo.setImage(check);
     acvo.setUserid(userid);
     
     if(abvo.getImage()!=null){
     adao.insert(abvo);
     }
     
     int cnt = dao.acwrite(acvo);
      return "redirect:/aclistForm";
   }
   
   @RequestMapping(value = "/aclistForm", method = RequestMethod.GET)
   public String aclistForm(
		   @RequestParam(value="page", defaultValue="1") int page
         , @RequestParam(value="searchText", defaultValue="") String searchText
         , HttpSession session, Model model, AccountBookVO acvo) {
      String userid = (String)session.getAttribute("loginid");
      ArrayList<AccountBookVO>acbook = new ArrayList<AccountBookVO>();
      
		//현재 페이지 전체 글 개수
		int total = dao.getTotal(userid);
		
		//한 페이지에 10개씩 리스트 출력
		PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
		model.addAttribute("navi", navi);
		model.addAttribute("searchText", searchText);
		model.addAttribute("error",null);
		//게시판리스트(페이지, 검색)
		acbook = dao.aclist(navi.getStartRecord(), navi.getCountPerPage(), userid);
      
		if(searchText.length()>0){
			logger.info("검색단어:{}",searchText);
			acvo.setActitle(searchText);
			acvo.setUserid(userid);
			acbook = dao.aclist2(navi.getStartRecord(), navi.getCountPerPage(), acvo);
			logger.info(""+acvo);
			
			if(acbook.size()==0){
				model.addAttribute("error","검색한 결과가 없습니다.");
			}
		}
		session.setAttribute("melist", acbook);
      
      int allprices = 0;
      ArrayList<AccountBookVO>allprice = new ArrayList();
      allprice = dao.acread(userid);
      for(int y = 0; y < acbook.size(); y++){
         String[] prices = acbook.get(y).getAcprice().split(",");
         for(int z = 0; z < prices.length; z++){
            allprices += Integer.parseInt(prices[z]);
         }
         allprice.get(y).setAcprice(String.valueOf(allprices));
         allprices = 0;
      }
      for(int x = 0; x < acbook.size(); x++){
      String items = acbook.get(x).getAcitem();
      String prices = acbook.get(x).getAcprice();
      items = items.replace(',', '\n');
      prices = prices.replace(',', '\n');
      acbook.get(x).setAcitem(items);
      acbook.get(x).setAcprice(prices);
      }
      model.addAttribute("aclist", acbook);
      model.addAttribute("allprice",allprice);
      return "accountbook/aclistForm";
   }
   
  	@RequestMapping(value = "/aclistwrite", method = RequestMethod.POST)
	public String aclistwrite(AccountBookVO acvo, Model model, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		ArrayList<AccountBookVO> acbook = new ArrayList<AccountBookVO>();
		acvo.setUserid(userid);
		acbook = dao.acrewriteread(acvo);
		String[] items = acbook.get(0).getAcitem().split(",");
		String[] prices = acbook.get(0).getAcprice().split(",");
		String[] types = acbook.get(0).getActype().split(",");
		List<String>it = new ArrayList<String>();
		List<String>pr = new ArrayList<String>();
		List<String>ty = new ArrayList<String>();
		for(int x = 0; x < items.length; x++){
			it.add(items[x]);
			pr.add(prices[x]);
			ty.add(types[x]);
		}
		logger.info("넘길값들:{}",it);
		session.setAttribute("aclist", acbook);
		session.setAttribute("price",pr);
		session.setAttribute("item",it);
		session.setAttribute("type", ty);
		return "redirect:acrewriteForm";
  	}
   
   @RequestMapping(value = "/acrewrite", method = RequestMethod.POST)
   public String acrewrite(AccountBookVO acvo, Model model, HttpSession session) {
      String userid = (String)session.getAttribute("loginid");
      ArrayList<AccountBookVO> acbook = new ArrayList<AccountBookVO>();
      acvo.setUserid(userid);
      int cnt = 0;
      cnt = dao.acrewriting(acvo);
      return "redirect:acrewriteForm";
   }
   
   @RequestMapping(value = "/acdelete", method = RequestMethod.GET)
   public String acdelete(AccountBookVO acvo, Model model, HttpSession session) {
      String userid = (String)session.getAttribute("loginid");
      ArrayList<AccountBookVO> acbook = new ArrayList<AccountBookVO>();
      acvo.setUserid(userid);
      logger.info("삭제될 값:{}",acvo);
      int cnt = 0;
      cnt = dao.acdelete(acvo);
      
      acbook = dao.acread(userid);
      int allprices = 0;
      ArrayList<AccountBookVO>allprice = new ArrayList();
      allprice = dao.acread(userid);
      for(int y = 0; y < acbook.size(); y++){
         String[] prices = acbook.get(y).getAcprice().split(",");
         for(int z = 0; z < prices.length; z++){
            allprices += Integer.parseInt(prices[z]);
         }
         allprice.get(y).setAcprice(String.valueOf(allprices));
         allprices = 0;
      }
      for(int x = 0; x < acbook.size(); x++){
      String items = acbook.get(x).getAcitem();
      String prices = acbook.get(x).getAcprice();
      items = items.replace(',', '\n');
      prices = prices.replace(',', '\n');
      acbook.get(x).setAcitem(items);
      acbook.get(x).setAcprice(prices);
      }
      model.addAttribute("aclist", acbook);
      model.addAttribute("allprice",allprice);
      return "redirect:aclistForm";
   }
   
   @RequestMapping(value = "/acOneread", method = RequestMethod.GET)
   public String acOneread(AccountBookVO acvo, int acnum, Model model, HttpSession session) {
      String userid = (String)session.getAttribute("loginid");
      ArrayList<AccountBookVO>acbook = new ArrayList();
      acvo.setAcnum(acnum);
      acvo.setUserid(userid);
      acbook = dao.acread1(acvo);
      int allprices = 0;
      ArrayList<AccountBookVO>allprice = new ArrayList();
      allprice = dao.acread(userid);
      for(int y = 0; y < acbook.size(); y++){
         String[] prices = acbook.get(y).getAcprice().split(",");
         for(int z = 0; z < prices.length; z++){
            allprices += Integer.parseInt(prices[z]);
         }
         allprice.get(y).setAcprice(String.valueOf(allprices));
         allprices = 0;
      }
      for(int x = 0; x < acbook.size(); x++){
      String items = acbook.get(x).getAcitem();
      String prices = acbook.get(x).getAcprice();
      items = items.replace(',', '\n');
      prices = prices.replace(',', '\n');
      acbook.get(x).setAcitem(items);
      acbook.get(x).setAcprice(prices);
      }
      model.addAttribute("aclist", acbook);
      model.addAttribute("allprice",allprice);
      return "accountbook/acOneread";
   }
}
