package Project.threeM.PicDiary.Controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Project.threeM.PicDiary.HomeController;
import Project.threeM.PicDiary.DAO.AccountBookDAO;
import Project.threeM.PicDiary.DAO.DiaryDAO;
import Project.threeM.PicDiary.VO.DiaryVO;
import Project.threeM.PicDiary.VO.UserinfoVO;
import Project.threeM.PicDiary.UTIL.PageNavigator;


@Controller
public class MainController {
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	//page당 글수
	private static final int countPerPage = 8;
	//page당 이동 링크 그룹당 페이지 수
	private static final int countPerGroup = 5;
	
	@Autowired
	DiaryDAO dao;
	
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main(@RequestParam(value="page", defaultValue="1") int page
					, @RequestParam(value="searchText", defaultValue="") String searchText
					, @RequestParam(value="label", defaultValue="") String label
					, HttpSession ses
					, Model model
					, HttpServletRequest request) {
		ArrayList<DiaryVO>list = new ArrayList<DiaryVO>();
		logger.debug("메인 페이지 지나감");
		logger.debug("페이지: {}, 분류 : {}, 검색어 : {}",page, label, searchText);
		list = dao.all();
		int total = 0;
		int CurrentPage = 0;
		int SumPage = 0;
		PageNavigator navi1 = null;
		String[] userimage = new String[list.size()];
		
		String loginid = (String) ses.getAttribute("loginid");
		
		try {			
			//현재 전체 글 개수
			total = list.size();
			logger.info("총 글 개수 : {}",total);
			
			PageNavigator navi = new PageNavigator(countPerPage, countPerGroup, page, total);
			
			//게시글 가지고 오기
			if(searchText != null && searchText != ""){
			list = dao.searchlist(navi.getStartRecord(), navi.getCountPerPage(), searchText);
			}
			//각 게시글 별 회원 프로필 이미지
			for(int x = 0; x < list.size(); x++){
				userimage[x] = dao.userimg(list.get(x).getUserid());
			}
			logger.debug(userimage[1]);
			navi1 = navi;
		}
		catch (Exception e) {
			e.printStackTrace();
			return "redirect:/";
		}
		
		ArrayList<DiaryVO>popular = new ArrayList<DiaryVO>();
		//인기게시글 가져오기
		popular = dao.popular();
		
		//각 게시글별 개수 가져오기
		int[] numbering = new int[5];
		numbering[0] = dao.numab(loginid);
		numbering[1] = dao.numdi(loginid);
		numbering[2] = dao.numac(loginid);
		numbering[3] = dao.numad(loginid);
		numbering[4] = dao.numme(loginid);

		ses.setAttribute("numb",numbering);
		ses.setAttribute("pop",popular);
		ses.setAttribute("navi", navi1);
		ses.setAttribute("countPerGroup", countPerGroup);
		model.addAttribute("searchText", searchText);
		model.addAttribute("label", label);
		model.addAttribute("alllist", list);
		model.addAttribute("userimg",userimage);
		return "main";
	}
	
	@RequestMapping(value = "/writeForm", method = RequestMethod.GET)
	public String writeForm() {
			
		return "writeForm";
	}
	
	@RequestMapping(value = "/contact", method = RequestMethod.GET)
	public String contact() {
			
		return "contact";
	}
}
