package Project.threeM.PicDiary.Controller;

import java.io.File;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Project.threeM.PicDiary.DAO.MemoDAO;
import Project.threeM.PicDiary.UTIL.APIExamSTT;
import Project.threeM.PicDiary.UTIL.PageNavigator;
import Project.threeM.PicDiary.VO.MemoVO;


@Controller
public class MemoController {
	private static final Logger logger = LoggerFactory.getLogger(MemoController.class);
	private static final int countPerPage = 6;		//페이지당 글 수
	private static final int pagePerGroup = 5;		//페이지 이동 링크 그룹 당 페이지 수
	
	
	@Autowired
	MemoDAO dao;
	
	//메모 리스트 폼 출력
	@RequestMapping(value = "/melistForm", method = RequestMethod.GET)
	public String melistForm(
			@RequestParam(value="page", defaultValue="1") int page
			,@RequestParam(value="searchText", defaultValue="") String searchText
			,HttpSession session, Model model, MemoVO mevo) {
		String userid = (String)session.getAttribute("loginid");
		ArrayList<MemoVO>list = new ArrayList<MemoVO>(); 
		//현재 페이지 전체 글 개수
		int total = dao.getTotal(searchText);
		//한 페이지에 10개씩 리스트 출력
		PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
		model.addAttribute("navi", navi);
		model.addAttribute("searchText", searchText);
		model.addAttribute("error",null);
		//게시판리스트(페이지, 검색)
		list = dao.melist(navi.getStartRecord(), navi.getCountPerPage(), userid);
		if(searchText.length()>0){
			logger.info("검색단어:{}",searchText);
			mevo.setMetitle(searchText);
			mevo.setUserid(userid);
			list = dao.melist2(navi.getStartRecord(), navi.getCountPerPage(), mevo);
			logger.info(""+list);

			if(list.size()==0){
				model.addAttribute("error","검색한 결과가 없습니다.");
			}
		}
		session.setAttribute("melist", list);
		return "memo/melistForm";
	}
	
	
	//메모 리스트 폼 출력
	@RequestMapping(value = "/meMain", method = RequestMethod.GET)
	public String meMain(
			@RequestParam(value="page", defaultValue="1") int page
			,@RequestParam(value="searchText", defaultValue="") String searchText
			,HttpSession session, Model model, MemoVO mevo) {
		String userid = (String)session.getAttribute("loginid");
		ArrayList<MemoVO>list = new ArrayList<MemoVO>(); 
		//현재 페이지 전체 글 개수
		int total = dao.getTotal(userid);
		//한 페이지에 10개씩 리스트 출력
		PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
		model.addAttribute("navi", navi);
		model.addAttribute("searchText", searchText);
		model.addAttribute("error",null);
		//게시판리스트(페이지, 검색)
		list = dao.melist(navi.getStartRecord(), navi.getCountPerPage(), userid);
		if(searchText.length()>0){
			logger.info("검색단어:{}",searchText);
			mevo.setMetitle(searchText);
			mevo.setUserid(userid);
			list = dao.melist2(navi.getStartRecord(), navi.getCountPerPage(), mevo);
			logger.info(""+list);

			if(list.size()==0){
				model.addAttribute("error","검색한 결과가 없습니다.");
			}
		}
		session.setAttribute("melist", list);
		return "memo/meMain";
	}
	
	//메모 등록(포스트잇 등록) from postit.js
	@ResponseBody
	@RequestMapping(value = "/mewrite", method = RequestMethod.POST)
	public void mewrite(MemoVO mevo, String metitle, String mecontent, String mevoice, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		mevoice = (String) session.getAttribute("url");
		logger.debug(mevoice);
		
		mevo.setUserid(userid);
		mevo.setMetitle(metitle);
		mevo.setMecontent(mecontent);
		if(mevoice==null||mevoice==""){
			mevoice = "등록된 음성이 없습니다.";
		}
		mevo.setMevoice(mevoice);
		dao.mewrite(mevo);
	}
	
	//메모 수정
	@RequestMapping(value = "/rewriting", method = RequestMethod.POST)
	public String rewriting(MemoVO mevo, String content, int menum, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		mevo.setUserid(userid);
		dao.update(mevo);
		return "redirect:melistForm";
	}
	
	//메모 삭제
	@RequestMapping(value = "/deleting", method = RequestMethod.POST)
	public String deleting(MemoVO mevo, int menum, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		mevo.setUserid(userid);
		dao.deleting(mevo);
		return "redirect:melistForm";
	}
	
	@ResponseBody
	@RequestMapping(value = "recorder", method = RequestMethod.POST, produces="application/json; charset=UTF-8")
	public String recorder_post(HttpSession session, String url, String fileName) {
		logger.debug("Blob주소 :" + url);
		logger.debug("파일명 :" + fileName);
		
		APIExamSTT stt = new APIExamSTT();
		String stt1 = null;
		String home = System.getProperty("user.home");
		File file = new File(home+"/Downloads/" + fileName);
		
		while(true) {
			boolean isExists = file.exists();

			if(isExists) { 
				System.out.println("I find the " + fileName);
				
				stt1 = stt.STT(fileName);
				logger.debug("이거뭐지:" + stt1);
				session.setAttribute("url", url);
				return stt1;
			} 
			else { 
				try {
					Thread.sleep(1000);
					System.out.println("No, there is not a no file.");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			continue;
			}
		}
	}
}
