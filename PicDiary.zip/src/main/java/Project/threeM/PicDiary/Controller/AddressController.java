package Project.threeM.PicDiary.Controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Project.threeM.PicDiary.DAO.AddressDAO;
import Project.threeM.PicDiary.DAO.AlbumDAO;
import Project.threeM.PicDiary.UTIL.PageNavigator;
import Project.threeM.PicDiary.VO.AddressVO;
import Project.threeM.PicDiary.VO.AlbumVO;

@Controller
public class AddressController {
	private static final Logger logger = LoggerFactory.getLogger(AddressController.class);
	private static final int countPerPage = 7;		//페이지당 글 수
	private static final int pagePerGroup = 5;		//페이지 이동 링크 그룹 당 페이지 수

	@Autowired
	AddressDAO dao;
	@Autowired
	AlbumDAO adao;

	@RequestMapping(value = "/adMain", method = RequestMethod.GET)
	public String acmain() {

		return "address/adMain";
	}
	//주소록 리스트
	@RequestMapping(value = "/adlistForm", method = RequestMethod.GET)
	public String adlistForm(
			@RequestParam(value="page", defaultValue="1") int page
			,@RequestParam(value="searchText", defaultValue="") String searchText
			,Model model, HttpSession session, AddressVO advo){
		String userid = (String)session.getAttribute("loginid");
		ArrayList<AddressVO>list = new ArrayList<AddressVO>();
		//		현재 전체 글 개수		
		int total = dao.getTotal(userid);
		//		한 페이지에 10개씩 리스트 출력		
		PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
		model.addAttribute("navi", navi);	
		model.addAttribute("searchText", searchText);
		model.addAttribute("error",null);
		//		앨범리스트( 페이지 , 검색 )
		list = dao.adlist(navi.getStartRecord(), navi.getCountPerPage(), userid);
		if(searchText.length()>0){
			advo.setAdname(searchText);
			advo.setUserid(userid);
			list = dao.adlist2(navi.getStartRecord(), navi.getCountPerPage(), advo);
			logger.info(""+list);
			if(list.size()==0){
				model.addAttribute("error","입력된 글이 존재하지 않습니다.");
			}
		}
		model.addAttribute("list", list);
		return "address/adlistForm";		
	}

	//직접 입력
	@RequestMapping(value = "/adwriteForm", method = RequestMethod.GET)
	public String adwriteForm() {

		return "address/adwriteForm";
	}

	// directWrite 폼 전송
	@RequestMapping(value = "/addiwrite", method = RequestMethod.POST)
	public String addiwrite(		
			AddressVO advo
			, HttpSession session
			, Model model) {
		logger.debug("advo:{}",advo);
		//세션에서 로그인한 사용자의 아이디를 읽어서 AddressVO객체의 userid에 세팅
		String userid = (String) session.getAttribute("loginid");
		advo.setUserid(userid);
		logger.debug("vo:{}",advo);
		//사진 등록
		dao.insertdi(advo);
		model.addAttribute("advo", advo);
		return "redirect:/adlistForm";
	}
	
	//주소록 : 사진으로 입력	
	@RequestMapping(value = "/adwrite", method = RequestMethod.POST)
	public String adwrite(
			AlbumVO abvo
			, AddressVO advo
			, HttpSession session
			, Model model) {
		logger.debug("advo:{}",advo);
		//세션에서 로그인한 사용자의 아이디를 읽어서 AddressVO객체의 userid에 세팅
		String userid = (String) session.getAttribute("loginid");
		abvo.setUserid(userid);
		advo.setUserid(userid);
		logger.debug("abvo:{}",abvo);
		logger.debug("vo:{}",advo);
		//사진 등록
		
		if(abvo.getImage()!=null){
		adao.insert(abvo);
		}
		
		dao.insert(advo);
		model.addAttribute("advo", advo);
		return "redirect:/adlistForm";
	}	
	
	//수정
	@RequestMapping(value = "/adrewriting", method = RequestMethod.POST)
	public String adrewritng(AddressVO advo, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		advo.setUserid(userid);
		dao.update(advo);
		return "redirect:/adlistForm";
	}
	//삭제
	@RequestMapping(value = "/addeleting", method = RequestMethod.POST)
	public String addeletng(AddressVO advo, HttpSession session) {
		String userid = (String)session.getAttribute("loginid");
		advo.setUserid(userid);
		dao.deleting(advo);
		return "redirect:/adlistForm";
	}
}
