package Project.threeM.PicDiary.Controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import Project.threeM.PicDiary.DAO.UserinfoDAO;
import Project.threeM.PicDiary.VO.UserinfoVO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class UserinfoController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserinfoController.class);

	@Autowired 
	UserinfoDAO usdao;

	//회원 가입 
	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public String joinForm(HttpSession session,Model model) {
		logger.info("회원가입 지나감");
/*		session.setAttribute("userid", "temp");
		model.addAttribute("idcheck", "");*/
		return "/userinfo/joinForm";
	}

	//회원 가입 처리
	@ResponseBody
	@RequestMapping(value = "ajaxjoin", method = RequestMethod.POST)
	public void ajaxjoin(UserinfoVO usvo) {
		logger.info("가입데이터: {}", usvo);
		String[] email = usvo.getEmail().split(",");	
		usvo.setEmail(email[0] + "@" + email[1]);
		
		logger.debug("{}", usvo.getEmail());
		
		//DAO로 전달하여 가입처리
		usdao.insert(usvo);	
	}
		
	//아이디 중복 확인 폼	
	@RequestMapping(value = "/idCheck", method = RequestMethod.GET)
	public String idCheck1() {
		logger.info("idCheck1");	
		return "userinfo/idCheck";
	}

	//아이디 중복 확인 후 가입폼으로 이동 (검색)	
	@RequestMapping(value = "/idCheck", method = RequestMethod.POST)
	public String idCheck2(String searchid, Model model) {
		logger.info("idCheck2");
		//ID를 전달하여 검색 결과를 VO객체로 받음
		UserinfoVO vo = usdao.getCustomer(searchid);
		//검색결과를 Model에 저장하고 JSP로 다시 이동
		
		if (searchid.length() < 3){
			model.addAttribute("search", false);
		}
		else {
			model.addAttribute("searchid", searchid);
			model.addAttribute("searchResult", vo);
			model.addAttribute("search", true);		
		}

			
		return "userinfo/idCheck";	
	}
	
	//로그인 폼
	@RequestMapping(value = "/loginForm", method = RequestMethod.GET)
	public String loginForm() {
		logger.debug("loginform지나감");
		
		return "/userinfo/loginForm";
	}
	
	//	로그인 - ajaxlogin (String 값으로 검색하여 세션에 로그인 정보 저장)
	@ResponseBody
	@RequestMapping(value = "ajaxlogin", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")	//ajax한글안깨지게
	public void ajaxlogin(
			String userid
			, String password
			, HttpSession session) {
		logger.debug("ajaxlogin 지나감");
		//입력받은 ID를 usvo에 set
		UserinfoVO usvo = new UserinfoVO();
		usvo.setUserid(userid);
		usvo.setPassword(password);

		logger.debug("usvo : {}", usvo);
		
		//사용자가 입력한 id와 password를 객체로 생성하여 회원 정보를 검색
		UserinfoVO vo = usdao.login(usvo);
		logger.debug("vo: {}",vo);
		
		//비밀번호 확인
		if(userid.equals(vo.getUserid()) && password.equals(vo.getPassword())) {
			//ID, 비번이 맞으면 세션에 "loginid"로 ID저장 , "loginName"으로 이름 저장
			session.setAttribute("inputid", userid); //사용자가 입력한 아이디 세션 저장
			session.setAttribute("loginid", vo.getUserid()); //서버에 저장된 아이디 세션 저장
			session.setAttribute("password", password);
			session.setAttribute("username", vo.getUsername());	
			session.setAttribute("userimage", vo.getUserimage());
		}
	}
	
	//로그아웃1
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		logger.info("logout() 지나감");

		session.invalidate(); 

		return "redirect:/";
	}
	
	//로그아웃1
	@RequestMapping(value = "/logout2", method = RequestMethod.GET)
	public String logout2(HttpSession session) {
		logger.info("logout2() 지나감");

		session.invalidate(); 

		return "redirect:/board/boardlist";
	}
	
	//회원 탈퇴 확인 창
	@RequestMapping(value = "/deleteAcc", method = RequestMethod.GET)
	public String deleteAcc() {
		logger.debug("deleteAcc지나감");

		return "/userinfo/deleteAcc";
	}

	//회원 탈퇴 처리
	@ResponseBody
	@RequestMapping(value = "/ajaxWithdrawal", method = RequestMethod.POST)
	public void delete(String userid, String password, HttpSession ses, Model model) {
		logger.info("ajaxWithdrawal 지나감");
		logger.debug("{},{}", userid, password);

		int result = 0;
		HashMap<String, String> map = new HashMap<>();

		map.put("userid", userid);
		map.put("password", password);

		logger.debug("{}",map);
		result = usdao.delete(map);
		ses.invalidate();
	}
	//회원정보수정폼	
		@RequestMapping(value = "/updateForm", method = RequestMethod.GET)
		public String updateForm(HttpSession session, Model model) {//session은 회원 한명마다 생성됨
			logger.info("updateForm");

			//세션에서 로그인아이디 읽기
			String loginid = (String)session.getAttribute("loginid");
			logger.debug("loginid:{}",loginid);

			//그 아이디로 DB에서 개인정보 검색하여 VO객체로 리턴
			UserinfoVO usvo = usdao.getCustomer(loginid);		

			//VO객체를 모델에 저장하고 수정폼 JSP로 포워딩
			String[] email = usvo.getEmail().split("@");
			model.addAttribute("userid", usvo.getUserid());
			model.addAttribute("username", usvo.getUsername());
			model.addAttribute("usemail1", email[0]);
			model.addAttribute("usemail2", email[1]);
			model.addAttribute("gender", usvo.getGender());
			model.addAttribute("age", usvo.getAge());
			model.addAttribute("userimage", usvo.getUserimage());
			return "userinfo/updateForm";
		}
		
		//사용자가 수정입력한 정보를 DB에 update
		@ResponseBody
		@RequestMapping(value = "/ajaxupdate", method = RequestMethod.POST)
		public void update(HttpSession session, UserinfoVO usvo) {	
			logger.info("update");
			String loginid = (String)session.getAttribute("loginid");
			usvo.setUserid(loginid);
			//이메일 주소 @를 붙여서 저장하기
			String[] email = usvo.getEmail().split(",");
			usvo.setEmail(email[0] + "@" + email[1]);
			logger.debug("{}",usvo);
			int cnt = usdao.update(usvo);
			//수정에 성공하면 세션의 로그인 사용자 이름도 수정

		}
		
		//수정된 결과를 보여주는 페이지로 이동
		@RequestMapping(value = "/updateInfo", method = RequestMethod.GET)
		public String updateInfo(HttpSession session, Model model) {
			logger.info("updateForm");
			String loginid = (String)session.getAttribute("loginid");
			UserinfoVO usvo = usdao.getCustomer(loginid);
			
			model.addAttribute("usvo", usvo);
			
			return "userinfo/updateInfo";
		}
	
	
}
