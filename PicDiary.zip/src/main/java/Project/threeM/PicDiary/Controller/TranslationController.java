package Project.threeM.PicDiary.Controller;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import Project.threeM.PicDiary.UTIL.APIExamTrans;

@Controller
public class TranslationController {

	private static final Logger logger = LoggerFactory.getLogger(TranslationController.class);

	@Autowired 
	SqlSession sqlSession;
	
	@ResponseBody
	@RequestMapping(value = "translation", method = RequestMethod.POST, produces="application/json; charset=UTF-8")
	public String translation(HttpSession session, String index, String type) {
		logger.debug("넘어옴 :" + index + type);
		
		APIExamTrans trans = new APIExamTrans();		
		String trans1 = null;
		
		trans1 = trans.translation(index, type);						
		logger.debug(trans1);
		
		return trans1;
	}
}
