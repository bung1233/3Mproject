package Project.threeM.PicDiary.Controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Project.threeM.PicDiary.DAO.AlbumDAO;
import Project.threeM.PicDiary.UTIL.PageNavigator;
import Project.threeM.PicDiary.VO.AlbumVO;

@Controller
public class AlbumController {
	private static final Logger logger = LoggerFactory.getLogger(AlbumController.class);
	
	private static final int countPerPage = 9;		//페이지당 글 수
	private static final int pagePerGroup = 5;		//페이지 이동 링크 그룹 당 페이지 수	
	
	@Autowired
	AlbumDAO dao;
	
	@RequestMapping(value = "/abMain", method = RequestMethod.GET)
	public String acmain() {
		
		return "album/abMain";
	}
	
	@RequestMapping(value = "/ablistForm", method = RequestMethod.GET)
	public String ablistForm(
			 @RequestParam(value="page", defaultValue="1") int page
			,@RequestParam(value="searchText", defaultValue="") String searchText
			,HttpSession ses, Model model, AlbumVO abvo){
		String userid = (String) ses.getAttribute("loginid");
		ArrayList<AlbumVO> list = new ArrayList<AlbumVO>();
//		현재 전체 글 개수
		int total = dao.getTotal(userid);
//		한 페이지에 10개씩 리스트 출력	
		PageNavigator navi = new PageNavigator(countPerPage,pagePerGroup, page, total);
//		앨범리스트( 페이지 , 검색 )
		model.addAttribute("navi", navi);
		model.addAttribute("searchText", searchText);
		model.addAttribute("error",null);
		list = dao.ablist(navi.getStartRecord(), navi.getCountPerPage(), userid);
		if(searchText.length()>0){
			logger.info("검색단어:{}",searchText);
			abvo.setAbtitle(searchText);
			abvo.setUserid(userid);
			list = dao.ablist2(navi.getStartRecord(), navi.getCountPerPage(), abvo);
			if(list.size()==0){
				model.addAttribute("error","검색한 결과가 없습니다.");
			}
		}
		ses.setAttribute("list", list);
		logger.debug("list:{}", list);
			
		return "album/ablistForm";
	}
}
