package Project.threeM.PicDiary;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page. 1
 */
@Controller
public class HomeController {
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		Date now = new Date();
		int ran = (int) (Math.random() * 5) + 1;
		
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy MMMMM dd EEEEE", Locale.UK);
		System.out.println(format1.format(now));
		String date = format1.format(now);
		String date_year = date.substring(0, 4);
		String date_month = date.substring(5, 10);
		String date_day = date.substring(11, 13);
		String date_E = date.substring(14, date.length());
		 
		System.out.println(date_year + date_month + date_day + date_E);
		
		SimpleDateFormat format2 = new SimpleDateFormat("MM", Locale.UK);
		System.out.println(format2.format(now));
		
		model.addAttribute("random", ran);
		model.addAttribute("now_year", date_year);
		model.addAttribute("now_month", date_month);
		model.addAttribute("now_day", date_day);
		model.addAttribute("now_E", date_E);		
		model.addAttribute("now2_month", format2.format(now));
		
		return "home";
	}
}
