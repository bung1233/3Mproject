package Project.threeM.PicDiary.VO;

public class AccountBookVO {
	int acnum;
	String userid;
	String actitle;
	String image;
	String acitem;
	String acprice;
	String actype;
	String acdate;
	
	public AccountBookVO(){}
	
	public AccountBookVO(String userid){
		this.userid = userid;
	}
	
	public int getAcnum() {
		return acnum;
	}
	public void setAcnum(int acnum) {
		this.acnum = acnum;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getActitle() {
		return actitle;
	}
	public void setActitle(String actitle) {
		this.actitle = actitle;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getAcitem() {
		return acitem;
	}
	public void setAcitem(String acitem) {
		this.acitem = acitem;
	}
	public String getAcprice() {
		return acprice;
	}
	public void setAcprice(String acprice) {
		this.acprice = acprice;
	}
	public String getActype() {
		return actype;
	}
	public void setActype(String actype) {
		this.actype = actype;
	}
	public String getAcdate() {
		return acdate;
	}
	public void setAcdate(String acdate) {
		this.acdate = acdate;
	}
	
	@Override
	public String toString() {
		return "AccountBookVO [acnum=" + acnum + ", userid=" + userid + ", actitle=" + actitle + ", image=" + image
				+ ", acitem=" + acitem + ", acprice=" + acprice + ", actype=" + actype + ", acdate=" + acdate + "]";
	}
	
	
}
