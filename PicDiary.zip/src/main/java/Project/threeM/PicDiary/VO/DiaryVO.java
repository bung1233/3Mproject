package Project.threeM.PicDiary.VO;

public class DiaryVO {

	int dinum;
	String userid;
	String dititle;
	String image;
	String dicontent;
	int dihit;
	String didate;  
	String dipublic;
	
	public DiaryVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DiaryVO(int dinum, String userid, String dititle, String image, String dicontent, int dihit, String didate,
			String dipublic) {
		super();
		this.dinum = dinum;
		this.userid = userid;
		this.dititle = dititle;
		this.image = image;
		this.dicontent = dicontent;
		this.dihit = dihit;
		this.didate = didate;
		this.dipublic = dipublic;
	}
	public int getDinum() {
		return dinum;
	}
	public void setDinum(int dinum) {
		this.dinum = dinum;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getDititle() {
		return dititle;
	}
	public void setDititle(String dititle) {
		this.dititle = dititle;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDicontent() {
		return dicontent;
	}
	public void setDicontent(String dicontent) {
		this.dicontent = dicontent;
	}
	public int getDihit() {
		return dihit;
	}
	public void setDihit(int dihit) {
		this.dihit = dihit;
	}
	public String getDidate() {
		return didate;
	}
	public void setDidate(String didate) {
		this.didate = didate;
	}
	public String getDipublic() {
		return dipublic;
	}
	public void setDipublic(String dipublic) {
		this.dipublic = dipublic;
	}
	@Override
	public String toString() {
		return "DiaryVO [dinum=" + dinum + ", userid=" + userid + ", dititle=" + dititle + ", image=" + image
				+ ", dicontent=" + dicontent + ", dihit=" + dihit + ", didate=" + didate + ", dipublic=" + dipublic
				+ "]";
	}
	
	
}



