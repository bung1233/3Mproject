package Project.threeM.PicDiary.VO;

public class AlbumVO {

	int abnum;    
	String userid;
	String abtitle;
	String image;  
	String abdate;
	String labeling;
	
	
	public AlbumVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AlbumVO(int abnum, String userid, String abtitle, String image, String abdate, String labeling) {
		super();
		this.abnum = abnum;
		this.userid = userid;
		this.abtitle = abtitle;
		this.image = image;
		this.abdate = abdate;
		this.labeling = labeling;
	}


	public int getAbnum() {
		return abnum;
	}


	public void setAbnum(int abnum) {
		this.abnum = abnum;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getAbtitle() {
		return abtitle;
	}


	public void setAbtitle(String abtitle) {
		this.abtitle = abtitle;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getAbdate() {
		return abdate;
	}


	public void setAbdate(String abdate) {
		this.abdate = abdate;
	}


	public String getLabeling() {
		return labeling;
	}


	public void setLabeling(String labeling) {
		this.labeling = labeling;
	}


	@Override
	public String toString() {
		return "AlbumVO [abnum=" + abnum + ", userid=" + userid + ", abtitle=" + abtitle + ", image=" + image
				+ ", abdate=" + abdate + ", labeling=" + labeling + "]";
	}

	
}



