package Project.threeM.PicDiary.VO;

public class AddressVO {

	int adnum;
	String userid;
	String adname;
	String image;
	String adcontent;
	public int getAdnum() {
		return adnum;
	}
	public void setAdnum(int adnum) {
		this.adnum = adnum;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getAdcontent() {
		return adcontent;
	}
	public void setAdcontent(String adcontent) {
		this.adcontent = adcontent;
	}
	@Override
	public String toString() {
		return "AddressVO [adnum=" + adnum + ", userid=" + userid + ", adname=" + adname + ", image=" + image
				+ ", adcontent=" + adcontent + "]";
	}
}
