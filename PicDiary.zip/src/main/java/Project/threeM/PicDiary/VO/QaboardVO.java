package Project.threeM.PicDiary.VO;

public class QaboardVO {
	int qanum;
	String userid;
	String qatitle;
	String qacontent;
	String qadate;
	
	public QaboardVO(){}
	
	public QaboardVO(int qanum,String userid,String qatitle,String qacontent,String qadate){
		this.qanum = qanum;
		this.userid = userid;
		this.qatitle = qatitle;
		this.qacontent = qacontent;
		this.qadate = qadate;
	}

	public int getQanum() {
		return qanum;
	}

	public void setQanum(int qanum) {
		this.qanum = qanum;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getQatitle() {
		return qatitle;
	}

	public void setQatitle(String qatitle) {
		this.qatitle = qatitle;
	}

	public String getQacontent() {
		return qacontent;
	}

	public void setQacontent(String qacontent) {
		this.qacontent = qacontent;
	}

	public String getQadate() {
		return qadate;
	}

	public void setQadate(String qadate) {
		this.qadate = qadate;
	}

	@Override
	public String toString() {
		return "QaboardVO [qanum=" + qanum + ", userid=" + userid + ", qatitle=" + qatitle + ", qacontent=" + qacontent
				+ ", qadate=" + qadate + "]";
	}
	
	
}
