package Project.threeM.PicDiary.VO;

public class MemoVO {
	int menum;
	String userid;
	String metitle;
	String mecontent;
	String mevoice;
	String medate;
	public int getMenum() {
		return menum;
	}
	public void setMenum(int menum) {
		this.menum = menum;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getMetitle() {
		return metitle;
	}
	public void setMetitle(String metitle) {
		this.metitle = metitle;
	}
	public String getMecontent() {
		return mecontent;
	}
	public void setMecontent(String mecontent) {
		this.mecontent = mecontent;
	}
	public String getMevoice() {
		return mevoice;
	}
	public void setMevoice(String mevoice) {
		this.mevoice = mevoice;
	}
	public String getMedate() {
		return medate;
	}
	public void setMedate(String medate) {
		this.medate = medate;
	}
	@Override
	public String toString() {
		return "MemoVO [menum=" + menum + ", userid=" + userid + ", metitle=" + metitle + ", mecontent=" + mecontent
				+ ", mevoice=" + mevoice + ", medate=" + medate + "]";
	}
	
}
